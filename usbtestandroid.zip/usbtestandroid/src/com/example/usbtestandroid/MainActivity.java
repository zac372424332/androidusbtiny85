package com.example.usbtestandroid;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;

import java.util.Iterator;
import java.util.Timer;

import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;



/*public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}*/


public class MainActivity extends Activity {

    TextView helloworldtextView;
    int USB_LED_OFF = 0;
    int USB_LED_ON = 1;
    int USB_DATA_OUT = 2;
    int USB_DATA_WRITE = 3;
    int USB_DATA_IN = 4;
    int USB_DATA_LONGOUT = 5;
    byte[] buffer = new byte[256];
    String str;
    int USB_TYPE_VENDOR = (0x02 << 5);
    int USB_RECIP_DEVICE = 0x00;
    int USB_ENDPOINT_IN = 0x00;
    int nBytes =0;
    Button BT_LED_ON, BT_LED_OFF, BT_RECEIVER_ON, BT_RECEIVER_OFF; 
    EditText ET_BUFFER;
    EditText LED_ID_BUFFER;
    TextView TV_BUFFER;
    UsbDeviceConnection connection;
    Timer timer=new Timer();
    
    
    private static final String ACTION_USB_PERMISSION =
    		"com.android.example.USB_PERMISSION";
    		private final BroadcastReceiver mUsbReceiver = new BroadcastReceiver() {

    		public void onReceive(Context context, Intent intent) {
    		    String action = intent.getAction();
    		    if (ACTION_USB_PERMISSION.equals(action)) {
    		        synchronized (this) {
    		            UsbDevice device = (UsbDevice)intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);

    		            if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
    		                if(device != null){
    		                  //call method to set up device communication
    		               }
    		            } 
    		            else {
    		                Log.d("TAG", "permission denied for device " + device);
    		            }
    		        }
    		    }
    		}
    	};
    
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR1) @SuppressLint("NewApi") @Override
    public void onCreate(Bundle savedInstanceState) {
    	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    	BT_LED_ON = (Button)findViewById(R.id.btledon);
    	BT_LED_OFF = (Button)findViewById(R.id.btledoff);
    	BT_RECEIVER_ON = (Button)findViewById(R.id.receiver1_button_on);
    	BT_RECEIVER_OFF = (Button)findViewById(R.id.receiver1_button_off);
    	ET_BUFFER = (EditText)findViewById(R.id.receiver1_editText);
    	LED_ID_BUFFER = (EditText)findViewById(R.id.LED_ID_editText);
    	TV_BUFFER = (TextView)findViewById(R.id.buffer_textView2);
    	BT_LED_ON.setOnClickListener(OCL_LED_ON);
    	BT_LED_OFF.setOnClickListener(OCL_LED_OFF);
    	BT_RECEIVER_ON.setOnClickListener(OCL_RECEIVER1_ON);
    	BT_RECEIVER_OFF.setOnClickListener(OCL_RECEIVER1_OFF);
    	

        UsbManager usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        HashMap<String, UsbDevice> devicelist = usbManager.getDeviceList();
        Iterator<UsbDevice> deviceIterator = devicelist.values().iterator();

        while(deviceIterator.hasNext()){

            UsbDevice device = deviceIterator.next();
            if(device.getProductId()==1500)
            {
	            PendingIntent mPermissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(ACTION_USB_PERMISSION), 0);
	            IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
	            registerReceiver(mUsbReceiver, filter);
	            usbManager.requestPermission(device, mPermissionIntent);
	            connection = usbManager.openDevice(device); 
	            UsbInterface intf = device.getInterface(0);
	            if (intf.getEndpointCount() != 1) 
	            {
	            	Toast.makeText(this, device.getDeviceName()+"could not find endpoint", Toast.LENGTH_LONG).show();
	                return; 
	            } 
	            if (connection != null && connection.claimInterface(intf, true))
	            {
	            	Toast.makeText(this, device.getDeviceName()+"device opened!", Toast.LENGTH_LONG).show();
	            	connection.controlTransfer(USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_ENDPOINT_IN, USB_LED_ON,0,0, buffer, buffer.length, 5000);
		            helloworldtextView = (TextView) findViewById(R.id.helloworldtext);
		            helloworldtextView.setText("device name:" + device.getDeviceName());
		            
		            
		            buffer = "Hello,Android USB".getBytes();
		            //nBytes = connection.controlTransfer(USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_ENDPOINT_IN, USB_DATA_IN,0,0, buffer, buffer.length, 5000);
		        	nBytes = connection.controlTransfer(USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_ENDPOINT_IN, USB_DATA_OUT,0,0, buffer, buffer.length, 5000);
		        	str=null;
		        	try {
		    			str = new String(buffer, "ASCII");
		    		} catch (UnsupportedEncodingException e) {
		    			// TODO Auto-generated catch block
		    			e.printStackTrace();
		    		}
		        	TV_BUFFER.setText("Got "+nBytes+"Bytes: " +str);
	            }
            }
            
        }
        
    }
    Button.OnClickListener OCL_LED_ON = new Button.OnClickListener()
    {

    	@Override
    	public void onClick(View v) 
    	{
    		if(helloworldtextView==null)helloworldtextView = (TextView) findViewById(R.id.helloworldtext);
    		if(helloworldtextView.getText().equals("USB device not connected"));
    		else{
    			buffer = null;
    			buffer = ("#"/*send 1 extra byte*/+LED_ID_BUFFER.getText().toString()+"ONE").getBytes();//E as end byte 
    			connection.controlTransfer(USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_ENDPOINT_IN, USB_DATA_IN,0,0, buffer, buffer.length, 5000);
    			nBytes = connection.controlTransfer(USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_ENDPOINT_IN, USB_DATA_OUT,0,0, buffer, buffer.length, 5000);
    			str=null;
    	    	try {
    				str = new String(buffer, "ASCII");
    			} catch (UnsupportedEncodingException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    	    	TV_BUFFER.setText("Got "+nBytes+"Bytes: " +str);
    		}
    	}
    };
    Button.OnClickListener OCL_LED_OFF = new Button.OnClickListener()
    {
    	@Override
    	public void onClick(View v) 
    	{
    		if(helloworldtextView==null)helloworldtextView = (TextView) findViewById(R.id.helloworldtext);
    		if(helloworldtextView.getText().equals("USB device not connected"));
    		else{
    			buffer = null;
    			buffer = ("#"/*send 1 extra byte*/+LED_ID_BUFFER.getText().toString()+"OFFE").getBytes();//E as end byte 
    			connection.controlTransfer(USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_ENDPOINT_IN, USB_DATA_IN,0,0, buffer , buffer.length, 5000);
    			nBytes = connection.controlTransfer(USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_ENDPOINT_IN, USB_DATA_OUT,0,0, buffer, buffer.length, 5000);
    			str=null;
    	    	try {
    				str = new String(buffer, "ASCII");
    			} catch (UnsupportedEncodingException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    	    	TV_BUFFER.setText("Got "+nBytes+"Bytes: " +str);
    		}
    	}
    };
    Button.OnClickListener OCL_RECEIVER1_ON = new Button.OnClickListener()
    {
    	@Override
    	public void onClick(View v) 
    	{
    		if(helloworldtextView==null)helloworldtextView = (TextView) findViewById(R.id.helloworldtext);
    		if(helloworldtextView.getText().equals("USB device not connected"));
    		else{
    			buffer = null;
    			buffer = ("#"/*send 1 extra byte*/+ET_BUFFER.getText().toString()+"ONE").getBytes();//E as end byte 
    			connection.controlTransfer(USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_ENDPOINT_IN, USB_DATA_IN,0,0, buffer, buffer.length, 5000);
    			nBytes = connection.controlTransfer(USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_ENDPOINT_IN, USB_DATA_OUT,0,0, buffer, buffer.length, 5000);
    			str=null;
    	    	try {
    				str = new String(buffer, "ASCII");
    			} catch (UnsupportedEncodingException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    	    	TV_BUFFER.setText("Got "+nBytes+"Bytes: " +str);
    		}
    	}
    };
    Button.OnClickListener OCL_RECEIVER1_OFF = new Button.OnClickListener()
    {
    	@Override
    	public void onClick(View v) 
    	{
    		if(helloworldtextView==null)helloworldtextView = (TextView) findViewById(R.id.helloworldtext);
    		if(helloworldtextView.getText().equals("USB device not connected"));
    		else{
    			buffer = null;
    			buffer = ("#"/*send 1 extra byte*/+ET_BUFFER.getText().toString()+"OFFE").getBytes();//E as end byte 
    			connection.controlTransfer(USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_ENDPOINT_IN, USB_DATA_IN,0,0, buffer , buffer.length, 5000);
    			nBytes = connection.controlTransfer(USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_ENDPOINT_IN, USB_DATA_OUT,0,0, buffer, buffer.length, 5000);
    			str=null;
    	    	try {
    				str = new String(buffer, "ASCII");
    			} catch (UnsupportedEncodingException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    	    	TV_BUFFER.setText("Got "+nBytes+"Bytes: " +str);
    		}
    	}
    };
    
    
}

